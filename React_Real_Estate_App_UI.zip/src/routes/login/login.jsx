import "./login.scss"

const Login = () => {
    return (
        <div className="login">
            Login
        </div>
    );
}

export default Login;